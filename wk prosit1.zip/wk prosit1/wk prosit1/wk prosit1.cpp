
#include "WK1E1.h"
#include <iostream>

int main()
{
    WK1E1* oo;//pointeur

    oo = new WK1E1();
    oo->message() ;//allocation dynamique
    delete (oo);
    WK1E1 obj;
    obj.message();//allocation statique

    
};
