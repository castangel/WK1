#include "WK1E1.h"
#include <iostream>
using namespace std;
void WK1E1::message() {

	cout << "Je renvoie un message\n";
}
