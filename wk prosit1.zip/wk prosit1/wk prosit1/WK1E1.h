#pragma once
class WK1E1
{

public:
	void message(void);
};

